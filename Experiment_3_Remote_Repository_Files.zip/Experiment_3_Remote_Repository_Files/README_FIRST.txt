DEVOPS LAB - EXPERIMENT III FILES

This ZIP contains starter files for the three merge demonstrations:
1. Fast_Forward
2. Three_Way_Merge
3. Merge_Conflict

IMPORTANT:
- Create a separate GitHub repository for each demonstration, as shown in your record.
- Upload only the contents of the relevant folder to that repository (not the parent ZIP folder).
- The feature-file-example.txt files are sample files. You can create/rename files during the steps in your record.
- For the merge-conflict demonstration, edit c1.txt differently on the feature branch and on GitHub/main after branching. Then pull and merge to produce a conflict.
- These are starter contents; your record does not specify every initial file's exact text.
