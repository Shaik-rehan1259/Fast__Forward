# Fast Forward Merge

Starter files for DevOps Lab Experiment III.
