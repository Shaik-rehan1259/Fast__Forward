# Merge Conflict

Starter files for demonstrating a Git merge conflict.
